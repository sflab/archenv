// This is a comment, it will not return an error.
#import "nothing.h"

int main(int argc, char const *argv[]) {
  /* code */
  return 0;
}
