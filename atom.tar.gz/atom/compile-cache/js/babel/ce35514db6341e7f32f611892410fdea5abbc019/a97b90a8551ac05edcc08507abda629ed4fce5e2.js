Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createDecoratedClass = (function () { function defineProperties(target, descriptors, initializers) { for (var i = 0; i < descriptors.length; i++) { var descriptor = descriptors[i]; var decorators = descriptor.decorators; var key = descriptor.key; delete descriptor.key; delete descriptor.decorators; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor || descriptor.initializer) descriptor.writable = true; if (decorators) { for (var f = 0; f < decorators.length; f++) { var decorator = decorators[f]; if (typeof decorator === 'function') { descriptor = decorator(target, key, descriptor) || descriptor; } else { throw new TypeError('The decorator for method ' + descriptor.key + ' is of the invalid type ' + typeof decorator); } } if (descriptor.initializer !== undefined) { initializers[key] = descriptor; continue; } } Object.defineProperty(target, key, descriptor); } } return function (Constructor, protoProps, staticProps, protoInitializers, staticInitializers) { if (protoProps) defineProperties(Constructor.prototype, protoProps, protoInitializers); if (staticProps) defineProperties(Constructor, staticProps, staticInitializers); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _defineDecoratedPropertyDescriptor(target, key, descriptors) { var _descriptor = descriptors[key]; if (!_descriptor) return; var descriptor = {}; for (var _key in _descriptor) descriptor[_key] = _descriptor[_key]; descriptor.value = descriptor.initializer ? descriptor.initializer.call(target) : undefined; Object.defineProperty(target, key, descriptor); }

var _mobx = require('mobx');

var _mobx2 = _interopRequireDefault(_mobx);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _season = require('season');

var _season2 = _interopRequireDefault(_season);

'use babel';

var Project = (function () {
  var _instanceInitializers = {};
  var _instanceInitializers = {};

  _createDecoratedClass(Project, [{
    key: 'props',
    decorators: [_mobx.observable],
    initializer: function initializer() {
      return {};
    },
    enumerable: true
  }, {
    key: 'title',
    decorators: [_mobx.computed],
    get: function get() {
      return this.props.title;
    }
  }, {
    key: 'paths',
    decorators: [_mobx.computed],
    get: function get() {
      var paths = this.props.paths.map(function (path) {
        if (path.charAt(0) === '~') {
          return path.replace('~', _os2['default'].homedir());
        }

        return path;
      });

      return paths;
    }
  }, {
    key: 'group',
    decorators: [_mobx.computed],
    get: function get() {
      return this.props.group;
    }
  }, {
    key: 'rootPath',
    decorators: [_mobx.computed],
    get: function get() {
      return this.paths[0];
    }
  }, {
    key: 'isCurrent',
    decorators: [_mobx.computed],
    get: function get() {
      var activePath = atom.project.getPaths()[0];

      if (activePath === this.rootPath) {
        return true;
      }

      return false;
    }
  }], [{
    key: 'defaultProps',
    get: function get() {
      return {
        title: '',
        group: '',
        paths: [],
        icon: 'icon-chevron-right',
        settings: {},
        devMode: false,
        template: null,
        source: null
      };
    }
  }], _instanceInitializers);

  function Project(props) {
    _classCallCheck(this, Project);

    _defineDecoratedPropertyDescriptor(this, 'props', _instanceInitializers);

    (0, _mobx.extendObservable)(this.props, Project.defaultProps);
    this.updateProps(props);
  }

  _createDecoratedClass(Project, [{
    key: 'updateProps',
    value: function updateProps(props) {
      (0, _mobx.extendObservable)(this.props, props);
    }
  }, {
    key: 'getProps',
    value: function getProps() {
      return _mobx2['default'].toJS(this.props);
    }
  }, {
    key: 'fetchLocalSettings',
    decorators: [_mobx.action],
    value: function fetchLocalSettings() {
      var _this = this;

      var file = this.rootPath + '/project.cson';
      _season2['default'].readFile(file, function (err, settings) {
        if (err) {
          return;
        }

        (0, _mobx.extendObservable)(_this.props.settings, settings);
      });
    }
  }, {
    key: 'lastModified',
    get: function get() {
      var mtime = 0;
      try {
        var stats = _fs2['default'].statSync(this.rootPath);
        mtime = stats.mtime;
      } catch (e) {
        mtime = new Date(0);
      }

      return mtime;
    }

    /**
     * Fetch settings that are saved locally with the project
     * if there are any.
     */
  }], null, _instanceInitializers);

  return Project;
})();

exports['default'] = Project;
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL3Byb2plY3QtbWFuYWdlci9saWIvbW9kZWxzL1Byb2plY3QuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O29CQUVxRSxNQUFNOzs7O2tCQUM1RCxJQUFJOzs7O2tCQUNKLElBQUk7Ozs7c0JBQ0YsUUFBUTs7OztBQUx6QixXQUFXLENBQUM7O0lBT1MsT0FBTzs7Ozt3QkFBUCxPQUFPOzs7O2FBQ04sRUFBRTs7Ozs7O1NBRUgsZUFBRztBQUNwQixhQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0tBQ3pCOzs7O1NBRWtCLGVBQUc7QUFDcEIsVUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQUEsSUFBSSxFQUFJO0FBQ3pDLFlBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7QUFDMUIsaUJBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsZ0JBQUcsT0FBTyxFQUFFLENBQUMsQ0FBQztTQUN4Qzs7QUFFRCxlQUFPLElBQUksQ0FBQztPQUNiLENBQUMsQ0FBQzs7QUFFSCxhQUFPLEtBQUssQ0FBQztLQUNkOzs7O1NBRWtCLGVBQUc7QUFDcEIsYUFBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztLQUN6Qjs7OztTQUVxQixlQUFHO0FBQ3ZCLGFBQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUN0Qjs7OztTQUVzQixlQUFHO0FBQ3hCLFVBQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7O0FBRTlDLFVBQUksVUFBVSxLQUFLLElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDaEMsZUFBTyxJQUFJLENBQUM7T0FDYjs7QUFFRCxhQUFPLEtBQUssQ0FBQztLQUNkOzs7U0FFc0IsZUFBRztBQUN4QixhQUFPO0FBQ0wsYUFBSyxFQUFFLEVBQUU7QUFDVCxhQUFLLEVBQUUsRUFBRTtBQUNULGFBQUssRUFBRSxFQUFFO0FBQ1QsWUFBSSxFQUFFLG9CQUFvQjtBQUMxQixnQkFBUSxFQUFFLEVBQUU7QUFDWixlQUFPLEVBQUUsS0FBSztBQUNkLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGNBQU0sRUFBRSxJQUFJO09BQ2IsQ0FBQztLQUNIOzs7QUFFVSxXQWxEUSxPQUFPLENBa0RkLEtBQUssRUFBRTswQkFsREEsT0FBTzs7OztBQW1EeEIsZ0NBQWlCLElBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ25ELFFBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7R0FDekI7O3dCQXJEa0IsT0FBTzs7V0F1RGYscUJBQUMsS0FBSyxFQUFFO0FBQ2pCLGtDQUFpQixJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3JDOzs7V0FFTyxvQkFBRztBQUNULGFBQU8sa0JBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztLQUM5Qjs7OztXQWtCeUIsOEJBQUc7OztBQUMzQixVQUFNLElBQUksR0FBTSxJQUFJLENBQUMsUUFBUSxrQkFBZSxDQUFDO0FBQzdDLDBCQUFLLFFBQVEsQ0FBQyxJQUFJLEVBQUUsVUFBQyxHQUFHLEVBQUUsUUFBUSxFQUFLO0FBQ3JDLFlBQUksR0FBRyxFQUFFO0FBQ1AsaUJBQU87U0FDUjs7QUFFRCxvQ0FBaUIsTUFBSyxLQUFLLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDO09BQ2pELENBQUMsQ0FBQztLQUNKOzs7U0F6QmUsZUFBRztBQUNqQixVQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7QUFDZCxVQUFJO0FBQ0YsWUFBTSxLQUFLLEdBQUcsZ0JBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN6QyxhQUFLLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztPQUNyQixDQUFDLE9BQU8sQ0FBQyxFQUFFO0FBQ1YsYUFBSyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO09BQ3JCOztBQUVELGFBQU8sS0FBSyxDQUFDO0tBQ2Q7Ozs7Ozs7O1NBekVrQixPQUFPOzs7cUJBQVAsT0FBTyIsImZpbGUiOiIvaG9tZS90YWthbm9yaS8uYXRvbS9wYWNrYWdlcy9wcm9qZWN0LW1hbmFnZXIvbGliL21vZGVscy9Qcm9qZWN0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCc7XG5cbmltcG9ydCBtb2J4LCB7IG9ic2VydmFibGUsIGNvbXB1dGVkLCBleHRlbmRPYnNlcnZhYmxlLCBhY3Rpb24gfSBmcm9tICdtb2J4JztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgb3MgZnJvbSAnb3MnO1xuaW1wb3J0IENTT04gZnJvbSAnc2Vhc29uJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUHJvamVjdCB7XG4gIEBvYnNlcnZhYmxlIHByb3BzID0ge31cblxuICBAY29tcHV0ZWQgZ2V0IHRpdGxlKCkge1xuICAgIHJldHVybiB0aGlzLnByb3BzLnRpdGxlO1xuICB9XG5cbiAgQGNvbXB1dGVkIGdldCBwYXRocygpIHtcbiAgICBjb25zdCBwYXRocyA9IHRoaXMucHJvcHMucGF0aHMubWFwKHBhdGggPT4ge1xuICAgICAgaWYgKHBhdGguY2hhckF0KDApID09PSAnficpIHtcbiAgICAgICAgcmV0dXJuIHBhdGgucmVwbGFjZSgnficsIG9zLmhvbWVkaXIoKSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBwYXRoO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHBhdGhzO1xuICB9XG5cbiAgQGNvbXB1dGVkIGdldCBncm91cCgpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9wcy5ncm91cDtcbiAgfVxuXG4gIEBjb21wdXRlZCBnZXQgcm9vdFBhdGgoKSB7XG4gICAgcmV0dXJuIHRoaXMucGF0aHNbMF07XG4gIH1cblxuICBAY29tcHV0ZWQgZ2V0IGlzQ3VycmVudCgpIHtcbiAgICBjb25zdCBhY3RpdmVQYXRoID0gYXRvbS5wcm9qZWN0LmdldFBhdGhzKClbMF07XG5cbiAgICBpZiAoYWN0aXZlUGF0aCA9PT0gdGhpcy5yb290UGF0aCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgc3RhdGljIGdldCBkZWZhdWx0UHJvcHMoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRpdGxlOiAnJyxcbiAgICAgIGdyb3VwOiAnJyxcbiAgICAgIHBhdGhzOiBbXSxcbiAgICAgIGljb246ICdpY29uLWNoZXZyb24tcmlnaHQnLFxuICAgICAgc2V0dGluZ3M6IHt9LFxuICAgICAgZGV2TW9kZTogZmFsc2UsXG4gICAgICB0ZW1wbGF0ZTogbnVsbCxcbiAgICAgIHNvdXJjZTogbnVsbCxcbiAgICB9O1xuICB9XG5cbiAgY29uc3RydWN0b3IocHJvcHMpIHtcbiAgICBleHRlbmRPYnNlcnZhYmxlKHRoaXMucHJvcHMsIFByb2plY3QuZGVmYXVsdFByb3BzKTtcbiAgICB0aGlzLnVwZGF0ZVByb3BzKHByb3BzKTtcbiAgfVxuXG4gIHVwZGF0ZVByb3BzKHByb3BzKSB7XG4gICAgZXh0ZW5kT2JzZXJ2YWJsZSh0aGlzLnByb3BzLCBwcm9wcyk7XG4gIH1cblxuICBnZXRQcm9wcygpIHtcbiAgICByZXR1cm4gbW9ieC50b0pTKHRoaXMucHJvcHMpO1xuICB9XG5cbiAgZ2V0IGxhc3RNb2RpZmllZCgpIHtcbiAgICBsZXQgbXRpbWUgPSAwO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKHRoaXMucm9vdFBhdGgpO1xuICAgICAgbXRpbWUgPSBzdGF0cy5tdGltZTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBtdGltZSA9IG5ldyBEYXRlKDApO1xuICAgIH1cblxuICAgIHJldHVybiBtdGltZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBGZXRjaCBzZXR0aW5ncyB0aGF0IGFyZSBzYXZlZCBsb2NhbGx5IHdpdGggdGhlIHByb2plY3RcbiAgICogaWYgdGhlcmUgYXJlIGFueS5cbiAgICovXG4gIEBhY3Rpb24gZmV0Y2hMb2NhbFNldHRpbmdzKCkge1xuICAgIGNvbnN0IGZpbGUgPSBgJHt0aGlzLnJvb3RQYXRofS9wcm9qZWN0LmNzb25gO1xuICAgIENTT04ucmVhZEZpbGUoZmlsZSwgKGVyciwgc2V0dGluZ3MpID0+IHtcbiAgICAgIGlmIChlcnIpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBleHRlbmRPYnNlcnZhYmxlKHRoaXMucHJvcHMuc2V0dGluZ3MsIHNldHRpbmdzKTtcbiAgICB9KTtcbiAgfVxufVxuIl19
//# sourceURL=/home/takanori/.atom/packages/project-manager/lib/models/Project.js
