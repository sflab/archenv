Object.defineProperty(exports, '__esModule', {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createDecoratedClass = (function () { function defineProperties(target, descriptors, initializers) { for (var i = 0; i < descriptors.length; i++) { var descriptor = descriptors[i]; var decorators = descriptor.decorators; var key = descriptor.key; delete descriptor.key; delete descriptor.decorators; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor || descriptor.initializer) descriptor.writable = true; if (decorators) { for (var f = 0; f < decorators.length; f++) { var decorator = decorators[f]; if (typeof decorator === 'function') { descriptor = decorator(target, key, descriptor) || descriptor; } else { throw new TypeError('The decorator for method ' + descriptor.key + ' is of the invalid type ' + typeof decorator); } } if (descriptor.initializer !== undefined) { initializers[key] = descriptor; continue; } } Object.defineProperty(target, key, descriptor); } } return function (Constructor, protoProps, staticProps, protoInitializers, staticInitializers) { if (protoProps) defineProperties(Constructor.prototype, protoProps, protoInitializers); if (staticProps) defineProperties(Constructor, staticProps, staticInitializers); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _defineDecoratedPropertyDescriptor(target, key, descriptors) { var _descriptor = descriptors[key]; if (!_descriptor) return; var descriptor = {}; for (var _key in _descriptor) descriptor[_key] = _descriptor[_key]; descriptor.value = descriptor.initializer ? descriptor.initializer.call(target) : undefined; Object.defineProperty(target, key, descriptor); }

var _mobx = require('mobx');

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _atomProjectUtil = require('atom-project-util');

var _atomProjectUtil2 = _interopRequireDefault(_atomProjectUtil);

var _storesFileStore = require('./stores/FileStore');

var _storesFileStore2 = _interopRequireDefault(_storesFileStore);

var _storesGitStore = require('./stores/GitStore');

var _storesGitStore2 = _interopRequireDefault(_storesGitStore);

var _Settings = require('./Settings');

var _Settings2 = _interopRequireDefault(_Settings);

var _modelsProject = require('./models/Project');

var _modelsProject2 = _interopRequireDefault(_modelsProject);

'use babel';

var Manager = (function () {
  var _instanceInitializers = {};
  var _instanceInitializers = {};

  _createDecoratedClass(Manager, [{
    key: 'addProject',
    decorators: [_mobx.action],
    value: function addProject(props) {
      var foundProject = this.projects.find(function (project) {
        var projectRootPath = project.rootPath.toLowerCase();
        var propsRootPath = props.paths[0].toLowerCase();

        if (propsRootPath.charAt(0) === '~') {
          propsRootPath = propsRootPath.replace('~', _os2['default'].homedir()).toLowerCase();
        }

        return projectRootPath === propsRootPath;
      });

      if (!foundProject) {
        var newProject = new _modelsProject2['default'](props);
        this.projects.push(newProject);
      } else {
        if (foundProject.source === 'file' && props.source === 'file') {
          foundProject.updateProps(props);
        }

        if (props.source === 'file' || typeof props.source === 'undefined') {
          foundProject.updateProps(props);
        }
      }
    }
  }, {
    key: 'projects',
    decorators: [_mobx.observable],
    initializer: function initializer() {
      return [];
    },
    enumerable: true
  }, {
    key: 'activePaths',
    decorators: [_mobx.observable],
    initializer: function initializer() {
      return [];
    },

    /**
     * Create or Update a project.
     *
     * Props coming from file goes before any other source.
     */
    enumerable: true
  }], null, _instanceInitializers);

  function Manager() {
    var _this = this;

    _classCallCheck(this, Manager);

    _defineDecoratedPropertyDescriptor(this, 'projects', _instanceInitializers);

    _defineDecoratedPropertyDescriptor(this, 'activePaths', _instanceInitializers);

    this.gitStore = new _storesGitStore2['default']();
    this.fileStore = new _storesFileStore2['default']();
    this.settings = new _Settings2['default']();

    this.fileStore.fetch();

    if (atom.config.get('project-manager.includeGitRepositories')) {
      this.gitStore.fetch();
    }

    atom.config.observe('project-manager.includeGitRepositories', function (include) {
      if (include) {
        _this.gitStore.fetch();
      } else {
        _this.gitStore.empty();
      }
    });

    (0, _mobx.autorun)(function () {
      for (var fileProp of _this.fileStore.data) {
        _this.addProject(fileProp);
      }

      for (var gitProp of _this.gitStore.data) {
        _this.addProject(gitProp);
      }
    });

    (0, _mobx.autorun)(function () {
      if (_this.activeProject) {
        _this.loadProject(_this.activeProject);
      }
    });

    this.activePaths = atom.project.getPaths();
    atom.project.onDidChangePaths(function () {
      _this.activePaths = atom.project.getPaths();
      var activePaths = atom.project.getPaths();

      if (_this.activeProject && _this.activeProject.rootPath === activePaths[0]) {
        if (_this.activeProject.paths.length !== activePaths.length) {
          _this.activeProject.updateProps({ paths: activePaths });
          _this.saveProjects();
        }
      }
    });
  }

  _createDecoratedClass(Manager, [{
    key: 'loadProject',
    value: function loadProject(project) {
      this.settings.load(project.getProps().settings);
    }
  }, {
    key: 'open',
    value: function open(project) {
      var openInSameWindow = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];

      if (this.isProject(project)) {
        var _project$getProps = project.getProps();

        var devMode = _project$getProps.devMode;

        if (openInSameWindow) {
          _atomProjectUtil2['default']['switch'](project.paths);
        } else {
          atom.open({
            devMode: devMode,
            pathsToOpen: project.paths
          });
        }
      }
    }
  }, {
    key: 'saveProject',
    value: function saveProject(props) {
      var propsToSave = props;
      if (this.isProject(props)) {
        propsToSave = props.getProps();
      }
      this.addProject(_extends({}, propsToSave, { source: 'file' }));
      this.saveProjects();
    }
  }, {
    key: 'saveProjects',
    value: function saveProjects() {
      var projects = this.projects.filter(function (project) {
        return project.props.source === 'file';
      });
      var arr = [];

      for (var project of projects) {
        var props = project.getProps();
        delete props.source;
        arr.push(props);
      }

      this.fileStore.store(arr);
    }
  }, {
    key: 'isProject',
    value: function isProject(project) {
      if (project instanceof _modelsProject2['default']) {
        return true;
      }

      return false;
    }
  }, {
    key: 'activeProject',
    decorators: [_mobx.computed],
    get: function get() {
      var _this2 = this;

      if (this.activePaths.length === 0) {
        return null;
      }

      return this.projects.find(function (project) {
        return project.rootPath === _this2.activePaths[0];
      });
    }
  }], null, _instanceInitializers);

  return Manager;
})();

var manager = new Manager();
exports['default'] = manager;
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL3Byb2plY3QtbWFuYWdlci9saWIvTWFuYWdlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztvQkFFc0QsTUFBTTs7a0JBQzdDLElBQUk7Ozs7K0JBQ0ssbUJBQW1COzs7OytCQUNyQixvQkFBb0I7Ozs7OEJBQ3JCLG1CQUFtQjs7Ozt3QkFDbkIsWUFBWTs7Ozs2QkFDYixrQkFBa0I7Ozs7QUFSdEMsV0FBVyxDQUFDOztJQVVOLE9BQU87Ozs7d0JBQVAsT0FBTzs7O1dBU08sb0JBQUMsS0FBSyxFQUFFO0FBQ3hCLFVBQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQUEsT0FBTyxFQUFJO0FBQ2pELFlBQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDdkQsWUFBSSxhQUFhLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQzs7QUFFakQsWUFBSSxhQUFhLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtBQUNuQyx1QkFBYSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLGdCQUFHLE9BQU8sRUFBRSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7U0FDeEU7O0FBRUQsZUFBTyxlQUFlLEtBQUssYUFBYSxDQUFDO09BQzFDLENBQUMsQ0FBQzs7QUFFSCxVQUFJLENBQUMsWUFBWSxFQUFFO0FBQ2pCLFlBQU0sVUFBVSxHQUFHLCtCQUFZLEtBQUssQ0FBQyxDQUFDO0FBQ3RDLFlBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO09BQ2hDLE1BQU07QUFDTCxZQUFJLFlBQVksQ0FBQyxNQUFNLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssTUFBTSxFQUFFO0FBQzdELHNCQUFZLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2pDOztBQUVELFlBQUksS0FBSyxDQUFDLE1BQU0sS0FBSyxNQUFNLElBQUksT0FBTyxLQUFLLENBQUMsTUFBTSxLQUFLLFdBQVcsRUFBRTtBQUNsRSxzQkFBWSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUNqQztPQUNGO0tBQ0Y7Ozs7O2FBaENzQixFQUFFOzs7Ozs7O2FBQ0MsRUFBRTs7Ozs7Ozs7Ozs7QUFpQ2pCLFdBbkNQLE9BQU8sR0FtQ0c7OzswQkFuQ1YsT0FBTzs7Ozs7O0FBb0NULFFBQUksQ0FBQyxRQUFRLEdBQUcsaUNBQWMsQ0FBQztBQUMvQixRQUFJLENBQUMsU0FBUyxHQUFHLGtDQUFlLENBQUM7QUFDakMsUUFBSSxDQUFDLFFBQVEsR0FBRywyQkFBYyxDQUFDOztBQUUvQixRQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDOztBQUV2QixRQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDLEVBQUU7QUFDN0QsVUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztLQUN2Qjs7QUFFRCxRQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyx3Q0FBd0MsRUFBRSxVQUFDLE9BQU8sRUFBSztBQUN6RSxVQUFJLE9BQU8sRUFBRTtBQUNYLGNBQUssUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO09BQ3ZCLE1BQU07QUFDTCxjQUFLLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztPQUN2QjtLQUNGLENBQUMsQ0FBQzs7QUFFSCx1QkFBUSxZQUFNO0FBQ1osV0FBSyxJQUFNLFFBQVEsSUFBSSxNQUFLLFNBQVMsQ0FBQyxJQUFJLEVBQUU7QUFDMUMsY0FBSyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7T0FDM0I7O0FBRUQsV0FBSyxJQUFNLE9BQU8sSUFBSSxNQUFLLFFBQVEsQ0FBQyxJQUFJLEVBQUU7QUFDeEMsY0FBSyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7T0FDMUI7S0FDRixDQUFDLENBQUM7O0FBRUgsdUJBQVEsWUFBTTtBQUNaLFVBQUksTUFBSyxhQUFhLEVBQUU7QUFDdEIsY0FBSyxXQUFXLENBQUMsTUFBSyxhQUFhLENBQUMsQ0FBQztPQUN0QztLQUNGLENBQUMsQ0FBQzs7QUFHSCxRQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDM0MsUUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFNO0FBQ2xDLFlBQUssV0FBVyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDM0MsVUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQzs7QUFFNUMsVUFBSSxNQUFLLGFBQWEsSUFBSSxNQUFLLGFBQWEsQ0FBQyxRQUFRLEtBQUssV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3hFLFlBQUksTUFBSyxhQUFhLENBQUMsS0FBSyxDQUFDLE1BQU0sS0FBSyxXQUFXLENBQUMsTUFBTSxFQUFFO0FBQzFELGdCQUFLLGFBQWEsQ0FBQyxXQUFXLENBQUMsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztBQUN2RCxnQkFBSyxZQUFZLEVBQUUsQ0FBQztTQUNyQjtPQUNGO0tBQ0YsQ0FBQyxDQUFDO0dBQ0o7O3dCQW5GRyxPQUFPOztXQTZGQSxxQkFBQyxPQUFPLEVBQUU7QUFDbkIsVUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBQ2pEOzs7V0FFRyxjQUFDLE9BQU8sRUFBNEI7VUFBMUIsZ0JBQWdCLHlEQUFHLEtBQUs7O0FBQ3BDLFVBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQ0FDUCxPQUFPLENBQUMsUUFBUSxFQUFFOztZQUE5QixPQUFPLHFCQUFQLE9BQU87O0FBRWYsWUFBSSxnQkFBZ0IsRUFBRTtBQUNwQixnREFBa0IsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDbkMsTUFBTTtBQUNMLGNBQUksQ0FBQyxJQUFJLENBQUM7QUFDUixtQkFBTyxFQUFQLE9BQU87QUFDUCx1QkFBVyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1dBQzNCLENBQUMsQ0FBQztTQUNKO09BQ0Y7S0FDRjs7O1dBRVUscUJBQUMsS0FBSyxFQUFFO0FBQ2pCLFVBQUksV0FBVyxHQUFHLEtBQUssQ0FBQztBQUN4QixVQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDekIsbUJBQVcsR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7T0FDaEM7QUFDRCxVQUFJLENBQUMsVUFBVSxjQUFNLFdBQVcsSUFBRSxNQUFNLEVBQUUsTUFBTSxJQUFHLENBQUM7QUFDcEQsVUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0tBQ3JCOzs7V0FFVyx3QkFBRztBQUNiLFVBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFVBQUEsT0FBTztlQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTSxLQUFLLE1BQU07T0FBQSxDQUFDLENBQUM7QUFDbEYsVUFBTSxHQUFHLEdBQUcsRUFBRSxDQUFDOztBQUVmLFdBQUssSUFBTSxPQUFPLElBQUksUUFBUSxFQUFFO0FBQzlCLFlBQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUNqQyxlQUFPLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDcEIsV0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztPQUNqQjs7QUFFRCxVQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUMzQjs7O1dBRVEsbUJBQUMsT0FBTyxFQUFFO0FBQ2pCLFVBQUksT0FBTyxzQ0FBbUIsRUFBRTtBQUM5QixlQUFPLElBQUksQ0FBQztPQUNiOztBQUVELGFBQU8sS0FBSyxDQUFDO0tBQ2Q7Ozs7U0F2RDBCLGVBQUc7OztBQUM1QixVQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtBQUNqQyxlQUFPLElBQUksQ0FBQztPQUNiOztBQUVELGFBQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBQSxPQUFPO2VBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFLLFdBQVcsQ0FBQyxDQUFDLENBQUM7T0FBQSxDQUFDLENBQUM7S0FDaEY7OztTQTNGRyxPQUFPOzs7QUErSWIsSUFBTSxPQUFPLEdBQUcsSUFBSSxPQUFPLEVBQUUsQ0FBQztxQkFDZixPQUFPIiwiZmlsZSI6Ii9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL3Byb2plY3QtbWFuYWdlci9saWIvTWFuYWdlci5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnO1xuXG5pbXBvcnQgeyBvYnNlcnZhYmxlLCBhdXRvcnVuLCBjb21wdXRlZCwgYWN0aW9uIH0gZnJvbSAnbW9ieCc7XG5pbXBvcnQgb3MgZnJvbSAnb3MnO1xuaW1wb3J0IHByb2plY3RVdGlsIGZyb20gJ2F0b20tcHJvamVjdC11dGlsJztcbmltcG9ydCBGaWxlU3RvcmUgZnJvbSAnLi9zdG9yZXMvRmlsZVN0b3JlJztcbmltcG9ydCBHaXRTdG9yZSBmcm9tICcuL3N0b3Jlcy9HaXRTdG9yZSc7XG5pbXBvcnQgU2V0dGluZ3MgZnJvbSAnLi9TZXR0aW5ncyc7XG5pbXBvcnQgUHJvamVjdCBmcm9tICcuL21vZGVscy9Qcm9qZWN0JztcblxuY2xhc3MgTWFuYWdlciB7XG4gIEBvYnNlcnZhYmxlIHByb2plY3RzID0gW107XG4gIEBvYnNlcnZhYmxlIGFjdGl2ZVBhdGhzID0gW107XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBvciBVcGRhdGUgYSBwcm9qZWN0LlxuICAgKlxuICAgKiBQcm9wcyBjb21pbmcgZnJvbSBmaWxlIGdvZXMgYmVmb3JlIGFueSBvdGhlciBzb3VyY2UuXG4gICAqL1xuICBAYWN0aW9uIGFkZFByb2plY3QocHJvcHMpIHtcbiAgICBjb25zdCBmb3VuZFByb2plY3QgPSB0aGlzLnByb2plY3RzLmZpbmQocHJvamVjdCA9PiB7XG4gICAgICBjb25zdCBwcm9qZWN0Um9vdFBhdGggPSBwcm9qZWN0LnJvb3RQYXRoLnRvTG93ZXJDYXNlKCk7XG4gICAgICBsZXQgcHJvcHNSb290UGF0aCA9IHByb3BzLnBhdGhzWzBdLnRvTG93ZXJDYXNlKCk7XG5cbiAgICAgIGlmIChwcm9wc1Jvb3RQYXRoLmNoYXJBdCgwKSA9PT0gJ34nKSB7XG4gICAgICAgIHByb3BzUm9vdFBhdGggPSBwcm9wc1Jvb3RQYXRoLnJlcGxhY2UoJ34nLCBvcy5ob21lZGlyKCkpLnRvTG93ZXJDYXNlKCk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBwcm9qZWN0Um9vdFBhdGggPT09IHByb3BzUm9vdFBhdGg7XG4gICAgfSk7XG5cbiAgICBpZiAoIWZvdW5kUHJvamVjdCkge1xuICAgICAgY29uc3QgbmV3UHJvamVjdCA9IG5ldyBQcm9qZWN0KHByb3BzKTtcbiAgICAgIHRoaXMucHJvamVjdHMucHVzaChuZXdQcm9qZWN0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGZvdW5kUHJvamVjdC5zb3VyY2UgPT09ICdmaWxlJyAmJiBwcm9wcy5zb3VyY2UgPT09ICdmaWxlJykge1xuICAgICAgICBmb3VuZFByb2plY3QudXBkYXRlUHJvcHMocHJvcHMpO1xuICAgICAgfVxuXG4gICAgICBpZiAocHJvcHMuc291cmNlID09PSAnZmlsZScgfHwgdHlwZW9mIHByb3BzLnNvdXJjZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgZm91bmRQcm9qZWN0LnVwZGF0ZVByb3BzKHByb3BzKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmdpdFN0b3JlID0gbmV3IEdpdFN0b3JlKCk7XG4gICAgdGhpcy5maWxlU3RvcmUgPSBuZXcgRmlsZVN0b3JlKCk7XG4gICAgdGhpcy5zZXR0aW5ncyA9IG5ldyBTZXR0aW5ncygpO1xuXG4gICAgdGhpcy5maWxlU3RvcmUuZmV0Y2goKTtcblxuICAgIGlmIChhdG9tLmNvbmZpZy5nZXQoJ3Byb2plY3QtbWFuYWdlci5pbmNsdWRlR2l0UmVwb3NpdG9yaWVzJykpIHtcbiAgICAgIHRoaXMuZ2l0U3RvcmUuZmV0Y2goKTtcbiAgICB9XG5cbiAgICBhdG9tLmNvbmZpZy5vYnNlcnZlKCdwcm9qZWN0LW1hbmFnZXIuaW5jbHVkZUdpdFJlcG9zaXRvcmllcycsIChpbmNsdWRlKSA9PiB7XG4gICAgICBpZiAoaW5jbHVkZSkge1xuICAgICAgICB0aGlzLmdpdFN0b3JlLmZldGNoKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmdpdFN0b3JlLmVtcHR5KCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBhdXRvcnVuKCgpID0+IHtcbiAgICAgIGZvciAoY29uc3QgZmlsZVByb3Agb2YgdGhpcy5maWxlU3RvcmUuZGF0YSkge1xuICAgICAgICB0aGlzLmFkZFByb2plY3QoZmlsZVByb3ApO1xuICAgICAgfVxuXG4gICAgICBmb3IgKGNvbnN0IGdpdFByb3Agb2YgdGhpcy5naXRTdG9yZS5kYXRhKSB7XG4gICAgICAgIHRoaXMuYWRkUHJvamVjdChnaXRQcm9wKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGF1dG9ydW4oKCkgPT4ge1xuICAgICAgaWYgKHRoaXMuYWN0aXZlUHJvamVjdCkge1xuICAgICAgICB0aGlzLmxvYWRQcm9qZWN0KHRoaXMuYWN0aXZlUHJvamVjdCk7XG4gICAgICB9XG4gICAgfSk7XG5cblxuICAgIHRoaXMuYWN0aXZlUGF0aHMgPSBhdG9tLnByb2plY3QuZ2V0UGF0aHMoKTtcbiAgICBhdG9tLnByb2plY3Qub25EaWRDaGFuZ2VQYXRocygoKSA9PiB7XG4gICAgICB0aGlzLmFjdGl2ZVBhdGhzID0gYXRvbS5wcm9qZWN0LmdldFBhdGhzKCk7XG4gICAgICBjb25zdCBhY3RpdmVQYXRocyA9IGF0b20ucHJvamVjdC5nZXRQYXRocygpO1xuXG4gICAgICBpZiAodGhpcy5hY3RpdmVQcm9qZWN0ICYmIHRoaXMuYWN0aXZlUHJvamVjdC5yb290UGF0aCA9PT0gYWN0aXZlUGF0aHNbMF0pIHtcbiAgICAgICAgaWYgKHRoaXMuYWN0aXZlUHJvamVjdC5wYXRocy5sZW5ndGggIT09IGFjdGl2ZVBhdGhzLmxlbmd0aCkge1xuICAgICAgICAgIHRoaXMuYWN0aXZlUHJvamVjdC51cGRhdGVQcm9wcyh7IHBhdGhzOiBhY3RpdmVQYXRocyB9KTtcbiAgICAgICAgICB0aGlzLnNhdmVQcm9qZWN0cygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBAY29tcHV0ZWQgZ2V0IGFjdGl2ZVByb2plY3QoKSB7XG4gICAgaWYgKHRoaXMuYWN0aXZlUGF0aHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5wcm9qZWN0cy5maW5kKHByb2plY3QgPT4gcHJvamVjdC5yb290UGF0aCA9PT0gdGhpcy5hY3RpdmVQYXRoc1swXSk7XG4gIH1cblxuICBsb2FkUHJvamVjdChwcm9qZWN0KSB7XG4gICAgdGhpcy5zZXR0aW5ncy5sb2FkKHByb2plY3QuZ2V0UHJvcHMoKS5zZXR0aW5ncyk7XG4gIH1cblxuICBvcGVuKHByb2plY3QsIG9wZW5JblNhbWVXaW5kb3cgPSBmYWxzZSkge1xuICAgIGlmICh0aGlzLmlzUHJvamVjdChwcm9qZWN0KSkge1xuICAgICAgY29uc3QgeyBkZXZNb2RlIH0gPSBwcm9qZWN0LmdldFByb3BzKCk7XG5cbiAgICAgIGlmIChvcGVuSW5TYW1lV2luZG93KSB7XG4gICAgICAgIHByb2plY3RVdGlsLnN3aXRjaChwcm9qZWN0LnBhdGhzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGF0b20ub3Blbih7XG4gICAgICAgICAgZGV2TW9kZSxcbiAgICAgICAgICBwYXRoc1RvT3BlbjogcHJvamVjdC5wYXRocyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgc2F2ZVByb2plY3QocHJvcHMpIHtcbiAgICBsZXQgcHJvcHNUb1NhdmUgPSBwcm9wcztcbiAgICBpZiAodGhpcy5pc1Byb2plY3QocHJvcHMpKSB7XG4gICAgICBwcm9wc1RvU2F2ZSA9IHByb3BzLmdldFByb3BzKCk7XG4gICAgfVxuICAgIHRoaXMuYWRkUHJvamVjdCh7IC4uLnByb3BzVG9TYXZlLCBzb3VyY2U6ICdmaWxlJyB9KTtcbiAgICB0aGlzLnNhdmVQcm9qZWN0cygpO1xuICB9XG5cbiAgc2F2ZVByb2plY3RzKCkge1xuICAgIGNvbnN0IHByb2plY3RzID0gdGhpcy5wcm9qZWN0cy5maWx0ZXIocHJvamVjdCA9PiBwcm9qZWN0LnByb3BzLnNvdXJjZSA9PT0gJ2ZpbGUnKTtcbiAgICBjb25zdCBhcnIgPSBbXTtcblxuICAgIGZvciAoY29uc3QgcHJvamVjdCBvZiBwcm9qZWN0cykge1xuICAgICAgY29uc3QgcHJvcHMgPSBwcm9qZWN0LmdldFByb3BzKCk7XG4gICAgICBkZWxldGUgcHJvcHMuc291cmNlO1xuICAgICAgYXJyLnB1c2gocHJvcHMpO1xuICAgIH1cblxuICAgIHRoaXMuZmlsZVN0b3JlLnN0b3JlKGFycik7XG4gIH1cblxuICBpc1Byb2plY3QocHJvamVjdCkge1xuICAgIGlmIChwcm9qZWN0IGluc3RhbmNlb2YgUHJvamVjdCkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbmNvbnN0IG1hbmFnZXIgPSBuZXcgTWFuYWdlcigpO1xuZXhwb3J0IGRlZmF1bHQgbWFuYWdlcjtcbiJdfQ==
//# sourceURL=/home/takanori/.atom/packages/project-manager/lib/Manager.js
