function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _findRepo = require('./find-repo');

var _findRepo2 = _interopRequireDefault(_findRepo);

var _gitWrapper = require('git-wrapper');

var _gitWrapper2 = _interopRequireDefault(_gitWrapper);

"use babel";

var showOpts = {
  s: true,
  format: '%ce%n%cn%n%B'
};

var cache = {};

function getCache(file, hash) {
  return cache[file + '|' + hash] || null;
}

function setCache(file, hash, msg) {
  cache[file + '|' + hash] = msg;
}

function getCommitMessage(file, hash, callback) {
  var repoPath = (0, _findRepo2['default'])(file);

  if (!repoPath) {
    return;
  }

  var git = new _gitWrapper2['default']({ 'git-dir': repoPath });
  git.exec('show', showOpts, [hash], function (error, msg) {
    if (error) {
      return;
    }
    callback(msg);
  });
}

function getCommit(file, hash, callback) {
  var cached = getCache(file, hash);

  if (cached) {
    return callback(cached);
  }

  getCommitMessage(file, hash, function (msg) {

    var lines = msg.split(/\n/g);

    var commit = {
      email: lines.shift(),
      author: lines.shift(),
      subject: lines.shift(),
      message: lines.join('\n').replace(/(^\s+|\s+$)/, '')
    };

    setCache(file, hash, commit);

    callback(commit);
  });
}

module.exports = getCommit;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL2JsYW1lL2xpYi91dGlscy9nZXQtY29tbWl0LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O3dCQUVxQixhQUFhOzs7OzBCQUNsQixhQUFhOzs7O0FBSDdCLFdBQVcsQ0FBQTs7QUFLWCxJQUFNLFFBQVEsR0FBRztBQUNmLEdBQUMsRUFBRSxJQUFJO0FBQ1AsUUFBTSxFQUFFLGNBQWM7Q0FDdkIsQ0FBQTs7QUFFRCxJQUFNLEtBQUssR0FBRyxFQUFFLENBQUE7O0FBRWhCLFNBQVMsUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7QUFDNUIsU0FBTyxLQUFLLENBQUksSUFBSSxTQUFJLElBQUksQ0FBRyxJQUFJLElBQUksQ0FBQTtDQUN4Qzs7QUFFRCxTQUFTLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRTtBQUNqQyxPQUFLLENBQUksSUFBSSxTQUFJLElBQUksQ0FBRyxHQUFHLEdBQUcsQ0FBQTtDQUMvQjs7QUFFRCxTQUFTLGdCQUFnQixDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO0FBQzlDLE1BQU0sUUFBUSxHQUFHLDJCQUFTLElBQUksQ0FBQyxDQUFBOztBQUUvQixNQUFJLENBQUMsUUFBUSxFQUFFO0FBQUUsV0FBTztHQUFFOztBQUUxQixNQUFNLEdBQUcsR0FBRyw0QkFBUSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFBO0FBQzVDLEtBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxDQUFFLElBQUksQ0FBRSxFQUFFLFVBQUMsS0FBSyxFQUFFLEdBQUcsRUFBSztBQUNuRCxRQUFJLEtBQUssRUFBRTtBQUFFLGFBQU07S0FBRTtBQUNyQixZQUFRLENBQUMsR0FBRyxDQUFDLENBQUE7R0FDZCxDQUFDLENBQUE7Q0FDSDs7QUFFRCxTQUFTLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtBQUN2QyxNQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFBOztBQUVuQyxNQUFJLE1BQU0sRUFBRTtBQUFFLFdBQU8sUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0dBQUU7O0FBRXZDLGtCQUFnQixDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsVUFBQyxHQUFHLEVBQUs7O0FBRXBDLFFBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7O0FBRTlCLFFBQU0sTUFBTSxHQUFHO0FBQ2IsV0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUU7QUFDcEIsWUFBTSxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUU7QUFDckIsYUFBTyxFQUFFLEtBQUssQ0FBQyxLQUFLLEVBQUU7QUFDdEIsYUFBTyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUM7S0FDckQsQ0FBQTs7QUFFRCxZQUFRLENBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQTs7QUFFNUIsWUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0dBQ2pCLENBQUMsQ0FBQTtDQUNIOztBQUdELE1BQU0sQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFBIiwiZmlsZSI6Ii9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL2JsYW1lL2xpYi91dGlscy9nZXQtY29tbWl0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgYmFiZWxcIlxuXG5pbXBvcnQgZmluZFJlcG8gZnJvbSAnLi9maW5kLXJlcG8nXG5pbXBvcnQgR2l0IGZyb20gJ2dpdC13cmFwcGVyJ1xuXG5jb25zdCBzaG93T3B0cyA9IHtcbiAgczogdHJ1ZSxcbiAgZm9ybWF0OiAnJWNlJW4lY24lbiVCJ1xufVxuXG5jb25zdCBjYWNoZSA9IHt9XG5cbmZ1bmN0aW9uIGdldENhY2hlKGZpbGUsIGhhc2gpIHtcbiAgcmV0dXJuIGNhY2hlW2Ake2ZpbGV9fCR7aGFzaH1gXSB8fCBudWxsXG59XG5cbmZ1bmN0aW9uIHNldENhY2hlKGZpbGUsIGhhc2gsIG1zZykge1xuICBjYWNoZVtgJHtmaWxlfXwke2hhc2h9YF0gPSBtc2dcbn1cblxuZnVuY3Rpb24gZ2V0Q29tbWl0TWVzc2FnZShmaWxlLCBoYXNoLCBjYWxsYmFjaykge1xuICBjb25zdCByZXBvUGF0aCA9IGZpbmRSZXBvKGZpbGUpXG5cbiAgaWYgKCFyZXBvUGF0aCkgeyByZXR1cm47IH1cblxuICBjb25zdCBnaXQgPSBuZXcgR2l0KHsgJ2dpdC1kaXInOiByZXBvUGF0aCB9KVxuICBnaXQuZXhlYygnc2hvdycsIHNob3dPcHRzLCBbIGhhc2ggXSwgKGVycm9yLCBtc2cpID0+IHtcbiAgICBpZiAoZXJyb3IpIHsgcmV0dXJuIH1cbiAgICBjYWxsYmFjayhtc2cpXG4gIH0pXG59XG5cbmZ1bmN0aW9uIGdldENvbW1pdChmaWxlLCBoYXNoLCBjYWxsYmFjaykge1xuICBjb25zdCBjYWNoZWQgPSBnZXRDYWNoZShmaWxlLCBoYXNoKVxuXG4gIGlmIChjYWNoZWQpIHsgcmV0dXJuIGNhbGxiYWNrKGNhY2hlZCkgfVxuXG4gIGdldENvbW1pdE1lc3NhZ2UoZmlsZSwgaGFzaCwgKG1zZykgPT4ge1xuXG4gICAgY29uc3QgbGluZXMgPSBtc2cuc3BsaXQoL1xcbi9nKVxuXG4gICAgY29uc3QgY29tbWl0ID0ge1xuICAgICAgZW1haWw6IGxpbmVzLnNoaWZ0KCksXG4gICAgICBhdXRob3I6IGxpbmVzLnNoaWZ0KCksXG4gICAgICBzdWJqZWN0OiBsaW5lcy5zaGlmdCgpLFxuICAgICAgbWVzc2FnZTogbGluZXMuam9pbignXFxuJykucmVwbGFjZSgvKF5cXHMrfFxccyskKS8sICcnKVxuICAgIH1cblxuICAgIHNldENhY2hlKGZpbGUsIGhhc2gsIGNvbW1pdClcblxuICAgIGNhbGxiYWNrKGNvbW1pdClcbiAgfSlcbn1cblxuXG5tb2R1bGUuZXhwb3J0cyA9IGdldENvbW1pdFxuIl19
//# sourceURL=/home/takanori/.atom/packages/blame/lib/utils/get-commit.js
