Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _findRepo = require('./find-repo');

var _findRepo2 = _interopRequireDefault(_findRepo);

var _gitWrapper = require('git-wrapper');

var _gitWrapper2 = _interopRequireDefault(_gitWrapper);

var _configProvider = require('../config/provider');

var _configProvider2 = _interopRequireDefault(_configProvider);

"use babel";

function parseRemote(remote, config) {
  for (var exp of config.exps) {
    var m = remote.match(exp);
    if (m) {
      return { protocol: m[1], host: m[2], user: m[3], repo: m[4] };
    }
  }

  return null;
}

function buildLink(remote, hash, config) {
  data = parseRemote(remote, config);
  if (data) {
    return config.template.replace('{protocol}', data.protocol || 'https').replace('{host}', data.host).replace('{user}', data.user).replace('{repo}', data.repo).replace('{hash}', hash);
  }

  return null;
}

function getConfig(git, key, callback) {
  git.exec('config', { get: true }, [key], callback);
}

function getCommitLink(file, hash, callback) {
  var repoPath = (0, _findRepo2['default'])(file);
  if (!repoPath) {
    return;
  }

  var git = new _gitWrapper2['default']({ 'git-dir': repoPath });
  getConfig(git, 'atom-blame.browser-url', function (error, url) {

    if (url) {
      var _link = url.replace(/(^\s+|\s+$)/g, '').replace('{hash}', hash);

      if (_link) {
        return callback(_link);
      }
    }

    getConfig(git, 'remote.origin.url', function (error, remote) {

      if (error) {
        return console.error(error);
      }

      remote = remote.replace(/(^\s+|\s+$)/g, '');

      for (var config of _configProvider2['default']) {
        link = buildLink(remote, hash, config);
        if (link) {
          return callback(link);
        }
      }

      callback(null);
    });
  });
}

exports['default'] = getCommitLink;
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL2JsYW1lL2xpYi91dGlscy9nZXQtY29tbWl0LWxpbmsuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O3dCQUVxQixhQUFhOzs7OzBCQUNsQixhQUFhOzs7OzhCQUNULG9CQUFvQjs7OztBQUp4QyxXQUFXLENBQUE7O0FBTVYsU0FBUyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRTtBQUNwQyxPQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUU7QUFDM0IsUUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUN6QixRQUFJLENBQUMsRUFBRTtBQUNMLGFBQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUE7S0FDOUQ7R0FDRjs7QUFFRCxTQUFPLElBQUksQ0FBQTtDQUNaOztBQUVELFNBQVMsU0FBUyxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFO0FBQ3ZDLE1BQUksR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFBO0FBQ2xDLE1BQUksSUFBSSxFQUFFO0FBQ1IsV0FBTyxNQUFNLENBQUMsUUFBUSxDQUNuQixPQUFPLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxRQUFRLElBQUksT0FBTyxDQUFDLENBQy9DLE9BQU8sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUM1QixPQUFPLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDNUIsT0FBTyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQzVCLE9BQU8sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUE7R0FDM0I7O0FBRUQsU0FBTyxJQUFJLENBQUE7Q0FDWjs7QUFFRCxTQUFTLFNBQVMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLFFBQVEsRUFBRTtBQUNyQyxLQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxDQUFFLEdBQUcsQ0FBRSxFQUFFLFFBQVEsQ0FBQyxDQUFBO0NBQ3JEOztBQUVELFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFO0FBQzNDLE1BQUksUUFBUSxHQUFHLDJCQUFTLElBQUksQ0FBQyxDQUFBO0FBQzdCLE1BQUksQ0FBQyxRQUFRLEVBQUU7QUFDYixXQUFNO0dBQ1A7O0FBRUQsTUFBSSxHQUFHLEdBQUcsNEJBQVEsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQTtBQUMxQyxXQUFTLENBQUMsR0FBRyxFQUFFLHdCQUF3QixFQUFFLFVBQUMsS0FBSyxFQUFFLEdBQUcsRUFBSzs7QUFFdkQsUUFBSSxHQUFHLEVBQUU7QUFDUCxVQUFJLEtBQUksR0FBRyxHQUFHLENBQ1gsT0FBTyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsQ0FDM0IsT0FBTyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQTs7QUFFMUIsVUFBSSxLQUFJLEVBQUU7QUFDUixlQUFPLFFBQVEsQ0FBQyxLQUFJLENBQUMsQ0FBQTtPQUN0QjtLQUNGOztBQUVELGFBQVMsQ0FBQyxHQUFHLEVBQUUsbUJBQW1CLEVBQUUsVUFBQyxLQUFLLEVBQUUsTUFBTSxFQUFLOztBQUVyRCxVQUFJLEtBQUssRUFBRTtBQUFFLGVBQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQTtPQUFFOztBQUUxQyxZQUFNLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUFDLENBQUE7O0FBRTNDLFdBQUssSUFBSSxNQUFNLGlDQUFhO0FBQzFCLFlBQUksR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQTtBQUN0QyxZQUFJLElBQUksRUFBRTtBQUNSLGlCQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQTtTQUN0QjtPQUNGOztBQUVELGNBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQTtLQUNmLENBQUMsQ0FBQTtHQUNILENBQUMsQ0FBQTtDQUNIOztxQkFFYyxhQUFhIiwiZmlsZSI6Ii9ob21lL3Rha2Fub3JpLy5hdG9tL3BhY2thZ2VzL2JsYW1lL2xpYi91dGlscy9nZXQtY29tbWl0LWxpbmsuanMiLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBiYWJlbFwiXG5cbmltcG9ydCBmaW5kUmVwbyBmcm9tICcuL2ZpbmQtcmVwbydcbmltcG9ydCBHaXQgZnJvbSAnZ2l0LXdyYXBwZXInXG5pbXBvcnQgY29uZmlncyBmcm9tICcuLi9jb25maWcvcHJvdmlkZXInXG5cbiBmdW5jdGlvbiBwYXJzZVJlbW90ZShyZW1vdGUsIGNvbmZpZykge1xuICBmb3IgKGxldCBleHAgb2YgY29uZmlnLmV4cHMpIHtcbiAgICBsZXQgbSA9IHJlbW90ZS5tYXRjaChleHApXG4gICAgaWYgKG0pIHtcbiAgICAgIHJldHVybiB7IHByb3RvY29sOiBtWzFdLCBob3N0OiBtWzJdLCB1c2VyOiBtWzNdLCByZXBvOiBtWzRdIH1cbiAgICB9XG4gIH1cblxuICByZXR1cm4gbnVsbFxufVxuXG5mdW5jdGlvbiBidWlsZExpbmsocmVtb3RlLCBoYXNoLCBjb25maWcpIHtcbiAgZGF0YSA9IHBhcnNlUmVtb3RlKHJlbW90ZSwgY29uZmlnKVxuICBpZiAoZGF0YSkge1xuICAgIHJldHVybiBjb25maWcudGVtcGxhdGVcbiAgICAgIC5yZXBsYWNlKCd7cHJvdG9jb2x9JywgZGF0YS5wcm90b2NvbCB8fCAnaHR0cHMnKVxuICAgICAgLnJlcGxhY2UoJ3tob3N0fScsIGRhdGEuaG9zdClcbiAgICAgIC5yZXBsYWNlKCd7dXNlcn0nLCBkYXRhLnVzZXIpXG4gICAgICAucmVwbGFjZSgne3JlcG99JywgZGF0YS5yZXBvKVxuICAgICAgLnJlcGxhY2UoJ3toYXNofScsIGhhc2gpXG4gIH1cblxuICByZXR1cm4gbnVsbFxufVxuXG5mdW5jdGlvbiBnZXRDb25maWcoZ2l0LCBrZXksIGNhbGxiYWNrKSB7XG4gIGdpdC5leGVjKCdjb25maWcnLCB7IGdldDogdHJ1ZSB9LCBbIGtleSBdLCBjYWxsYmFjaylcbn1cblxuZnVuY3Rpb24gZ2V0Q29tbWl0TGluayhmaWxlLCBoYXNoLCBjYWxsYmFjaykge1xuICBsZXQgcmVwb1BhdGggPSBmaW5kUmVwbyhmaWxlKVxuICBpZiAoIXJlcG9QYXRoKSB7XG4gICAgcmV0dXJuXG4gIH1cblxuICBsZXQgZ2l0ID0gbmV3IEdpdCh7ICdnaXQtZGlyJzogcmVwb1BhdGggfSlcbiAgZ2V0Q29uZmlnKGdpdCwgJ2F0b20tYmxhbWUuYnJvd3Nlci11cmwnLCAoZXJyb3IsIHVybCkgPT4ge1xuXG4gICAgaWYgKHVybCkge1xuICAgICAgbGV0IGxpbmsgPSB1cmxcbiAgICAgICAgLnJlcGxhY2UoLyheXFxzK3xcXHMrJCkvZywgJycpXG4gICAgICAgIC5yZXBsYWNlKCd7aGFzaH0nLCBoYXNoKVxuXG4gICAgICBpZiAobGluaykge1xuICAgICAgICByZXR1cm4gY2FsbGJhY2sobGluaylcbiAgICAgIH1cbiAgICB9XG5cbiAgICBnZXRDb25maWcoZ2l0LCAncmVtb3RlLm9yaWdpbi51cmwnLCAoZXJyb3IsIHJlbW90ZSkgPT4ge1xuXG4gICAgICBpZiAoZXJyb3IpIHsgcmV0dXJuIGNvbnNvbGUuZXJyb3IoZXJyb3IpIH1cblxuICAgICAgcmVtb3RlID0gcmVtb3RlLnJlcGxhY2UoLyheXFxzK3xcXHMrJCkvZywgJycpXG5cbiAgICAgIGZvciAobGV0IGNvbmZpZyBvZiBjb25maWdzKSB7XG4gICAgICAgIGxpbmsgPSBidWlsZExpbmsocmVtb3RlLCBoYXNoLCBjb25maWcpXG4gICAgICAgIGlmIChsaW5rKSB7XG4gICAgICAgICAgcmV0dXJuIGNhbGxiYWNrKGxpbmspXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY2FsbGJhY2sobnVsbClcbiAgICB9KVxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBnZXRDb21taXRMaW5rXG4iXX0=
//# sourceURL=/home/takanori/.atom/packages/blame/lib/utils/get-commit-link.js
