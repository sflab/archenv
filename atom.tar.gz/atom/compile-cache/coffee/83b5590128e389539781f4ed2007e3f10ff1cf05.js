(function() {
  var CompositeDisposable, MinimapBookmarksBinding, requirePackages;

  CompositeDisposable = require('atom').CompositeDisposable;

  requirePackages = require('atom-utils').requirePackages;

  MinimapBookmarksBinding = null;

  module.exports = {
    active: false,
    isActive: function() {
      return this.active;
    },
    bindings: {},
    activate: function(state) {},
    consumeMinimapServiceV1: function(minimap) {
      this.minimap = minimap;
      return this.minimap.registerPlugin('bookmarks', this);
    },
    deactivate: function() {
      var _ref;
      if ((_ref = this.minimap) != null) {
        _ref.unregisterPlugin('bookmarks');
      }
      return this.minimap = null;
    },
    activatePlugin: function() {
      if (this.active) {
        return;
      }
      return requirePackages('bookmarks').then((function(_this) {
        return function(_arg) {
          var bookmarks;
          bookmarks = _arg[0];
          _this.subscriptions = new CompositeDisposable;
          _this.active = true;
          return _this.minimapsSubscription = _this.minimap.observeMinimaps(function(minimap) {
            var binding, subscription;
            if (MinimapBookmarksBinding == null) {
              MinimapBookmarksBinding = require('./minimap-bookmarks-binding');
            }
            binding = new MinimapBookmarksBinding(minimap, bookmarks);
            _this.bindings[minimap.id] = binding;
            return _this.subscriptions.add(subscription = minimap.onDidDestroy(function() {
              binding.destroy();
              _this.subscriptions.remove(subscription);
              subscription.dispose();
              return delete _this.bindings[minimap.id];
            }));
          });
        };
      })(this));
    },
    deactivatePlugin: function() {
      var binding, id, _ref;
      if (!this.active) {
        return;
      }
      _ref = this.bindings;
      for (id in _ref) {
        binding = _ref[id];
        binding.destroy();
      }
      this.bindings = {};
      this.active = false;
      this.minimapsSubscription.dispose();
      return this.subscriptions.dispose();
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvdGFrYW5vcmkvLmF0b20vcGFja2FnZXMvbWluaW1hcC1ib29rbWFya3MvbGliL21pbmltYXAtYm9va21hcmtzLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSw2REFBQTs7QUFBQSxFQUFDLHNCQUF1QixPQUFBLENBQVEsTUFBUixFQUF2QixtQkFBRCxDQUFBOztBQUFBLEVBQ0Msa0JBQW1CLE9BQUEsQ0FBUSxZQUFSLEVBQW5CLGVBREQsQ0FBQTs7QUFBQSxFQUdBLHVCQUFBLEdBQTBCLElBSDFCLENBQUE7O0FBQUEsRUFLQSxNQUFNLENBQUMsT0FBUCxHQUNFO0FBQUEsSUFBQSxNQUFBLEVBQVEsS0FBUjtBQUFBLElBRUEsUUFBQSxFQUFVLFNBQUEsR0FBQTthQUFHLElBQUMsQ0FBQSxPQUFKO0lBQUEsQ0FGVjtBQUFBLElBSUEsUUFBQSxFQUFVLEVBSlY7QUFBQSxJQU1BLFFBQUEsRUFBVSxTQUFDLEtBQUQsR0FBQSxDQU5WO0FBQUEsSUFRQSx1QkFBQSxFQUF5QixTQUFFLE9BQUYsR0FBQTtBQUN2QixNQUR3QixJQUFDLENBQUEsVUFBQSxPQUN6QixDQUFBO2FBQUEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxjQUFULENBQXdCLFdBQXhCLEVBQXFDLElBQXJDLEVBRHVCO0lBQUEsQ0FSekI7QUFBQSxJQVdBLFVBQUEsRUFBWSxTQUFBLEdBQUE7QUFDVixVQUFBLElBQUE7O1lBQVEsQ0FBRSxnQkFBVixDQUEyQixXQUEzQjtPQUFBO2FBQ0EsSUFBQyxDQUFBLE9BQUQsR0FBVyxLQUZEO0lBQUEsQ0FYWjtBQUFBLElBZUEsY0FBQSxFQUFnQixTQUFBLEdBQUE7QUFDZCxNQUFBLElBQVUsSUFBQyxDQUFBLE1BQVg7QUFBQSxjQUFBLENBQUE7T0FBQTthQUVBLGVBQUEsQ0FBZ0IsV0FBaEIsQ0FBNEIsQ0FBQyxJQUE3QixDQUFrQyxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxJQUFELEdBQUE7QUFDaEMsY0FBQSxTQUFBO0FBQUEsVUFEa0MsWUFBRCxPQUNqQyxDQUFBO0FBQUEsVUFBQSxLQUFDLENBQUEsYUFBRCxHQUFpQixHQUFBLENBQUEsbUJBQWpCLENBQUE7QUFBQSxVQUNBLEtBQUMsQ0FBQSxNQUFELEdBQVUsSUFEVixDQUFBO2lCQUdBLEtBQUMsQ0FBQSxvQkFBRCxHQUF3QixLQUFDLENBQUEsT0FBTyxDQUFDLGVBQVQsQ0FBeUIsU0FBQyxPQUFELEdBQUE7QUFDL0MsZ0JBQUEscUJBQUE7O2NBQUEsMEJBQTJCLE9BQUEsQ0FBUSw2QkFBUjthQUEzQjtBQUFBLFlBQ0EsT0FBQSxHQUFjLElBQUEsdUJBQUEsQ0FBd0IsT0FBeEIsRUFBaUMsU0FBakMsQ0FEZCxDQUFBO0FBQUEsWUFFQSxLQUFDLENBQUEsUUFBUyxDQUFBLE9BQU8sQ0FBQyxFQUFSLENBQVYsR0FBd0IsT0FGeEIsQ0FBQTttQkFJQSxLQUFDLENBQUEsYUFBYSxDQUFDLEdBQWYsQ0FBbUIsWUFBQSxHQUFlLE9BQU8sQ0FBQyxZQUFSLENBQXFCLFNBQUEsR0FBQTtBQUNyRCxjQUFBLE9BQU8sQ0FBQyxPQUFSLENBQUEsQ0FBQSxDQUFBO0FBQUEsY0FDQSxLQUFDLENBQUEsYUFBYSxDQUFDLE1BQWYsQ0FBc0IsWUFBdEIsQ0FEQSxDQUFBO0FBQUEsY0FFQSxZQUFZLENBQUMsT0FBYixDQUFBLENBRkEsQ0FBQTtxQkFHQSxNQUFBLENBQUEsS0FBUSxDQUFBLFFBQVMsQ0FBQSxPQUFPLENBQUMsRUFBUixFQUpvQztZQUFBLENBQXJCLENBQWxDLEVBTCtDO1VBQUEsQ0FBekIsRUFKUTtRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDLEVBSGM7SUFBQSxDQWZoQjtBQUFBLElBaUNBLGdCQUFBLEVBQWtCLFNBQUEsR0FBQTtBQUNoQixVQUFBLGlCQUFBO0FBQUEsTUFBQSxJQUFBLENBQUEsSUFBZSxDQUFBLE1BQWY7QUFBQSxjQUFBLENBQUE7T0FBQTtBQUVBO0FBQUEsV0FBQSxVQUFBOzJCQUFBO0FBQUEsUUFBQSxPQUFPLENBQUMsT0FBUixDQUFBLENBQUEsQ0FBQTtBQUFBLE9BRkE7QUFBQSxNQUdBLElBQUMsQ0FBQSxRQUFELEdBQVksRUFIWixDQUFBO0FBQUEsTUFJQSxJQUFDLENBQUEsTUFBRCxHQUFVLEtBSlYsQ0FBQTtBQUFBLE1BS0EsSUFBQyxDQUFBLG9CQUFvQixDQUFDLE9BQXRCLENBQUEsQ0FMQSxDQUFBO2FBTUEsSUFBQyxDQUFBLGFBQWEsQ0FBQyxPQUFmLENBQUEsRUFQZ0I7SUFBQSxDQWpDbEI7R0FORixDQUFBO0FBQUEiCn0=

//# sourceURL=/home/takanori/.atom/packages/minimap-bookmarks/lib/minimap-bookmarks.coffee
