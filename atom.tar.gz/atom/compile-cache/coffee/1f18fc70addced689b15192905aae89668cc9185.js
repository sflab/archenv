(function() {
  var SublimeSelectEditorHandler, defaultCfg, inputCfg, key, mouseNumMap, os, packageName, selectKeyMap, value;

  packageName = "Sublime-Style-Column-Selection";

  os = require('os');

  SublimeSelectEditorHandler = require('./editor-handler.coffee');

  defaultCfg = (function() {
    switch (os.platform()) {
      case 'win32':
        return {
          selectKey: 'altKey',
          selectKeyName: 'Alt',
          mouseNum: 1,
          mouseName: "Left"
        };
      case 'darwin':
        return {
          selectKey: 'altKey',
          selectKeyName: 'Alt',
          mouseNum: 1,
          mouseName: "Left"
        };
      case 'linux':
        return {
          selectKey: 'shiftKey',
          selectKeyName: 'Shift',
          mouseNum: 1,
          mouseName: "Left"
        };
      default:
        return {
          selectKey: 'shiftKey',
          selectKeyName: 'Shift',
          mouseNum: 1,
          mouseName: "Left"
        };
    }
  })();

  mouseNumMap = {
    Left: 1,
    Middle: 2,
    Right: 3
  };

  selectKeyMap = {
    Shift: 'shiftKey',
    Alt: 'altKey',
    Ctrl: 'ctrlKey'
  };

  if (os.platform() === 'darwin') {
    selectKeyMap.Cmd = 'metaKey';
  }

  selectKeyMap.None = null;

  inputCfg = defaultCfg;

  module.exports = {
    config: {
      mouseButtonTrigger: {
        title: "Mouse Button",
        description: "The mouse button that will trigger column selection. If empty, the default will be used " + defaultCfg.mouseName + " mouse button.",
        type: 'string',
        "enum": (function() {
          var _results;
          _results = [];
          for (key in mouseNumMap) {
            value = mouseNumMap[key];
            _results.push(key);
          }
          return _results;
        })(),
        "default": defaultCfg.mouseName
      },
      selectKeyTrigger: {
        title: "Select Key",
        description: "The key that will trigger column selection. If empty, the default will be used " + defaultCfg.selectKeyName + " key.",
        type: 'string',
        "enum": (function() {
          var _results;
          _results = [];
          for (key in selectKeyMap) {
            value = selectKeyMap[key];
            _results.push(key);
          }
          return _results;
        })(),
        "default": defaultCfg.selectKeyName
      }
    },
    activate: function(state) {
      this.observers = [];
      this.editor_handler = null;
      this.observers.push(atom.config.observe("" + packageName + ".mouseButtonTrigger", (function(_this) {
        return function(newValue) {
          inputCfg.mouseName = newValue;
          return inputCfg.mouseNum = mouseNumMap[newValue];
        };
      })(this)));
      this.observers.push(atom.config.observe("" + packageName + ".selectKeyTrigger", (function(_this) {
        return function(newValue) {
          inputCfg.selectKeyName = newValue;
          return inputCfg.selectKey = selectKeyMap[newValue];
        };
      })(this)));
      this.observers.push(atom.workspace.onDidChangeActivePaneItem(this.switch_editor_handler));
      this.observers.push(atom.workspace.onDidAddPane(this.switch_editor_handler));
      return this.observers.push(atom.workspace.onDidDestroyPane(this.switch_editor_handler));
    },
    deactivate: function() {
      var observer, _i, _len, _ref, _ref1;
      if ((_ref = this.editor_handler) != null) {
        _ref.unsubscribe();
      }
      _ref1 = this.observers;
      for (_i = 0, _len = _ref1.length; _i < _len; _i++) {
        observer = _ref1[_i];
        observer.dispose();
      }
      this.observers = null;
      return this.editor_handler = null;
    },
    switch_editor_handler: (function(_this) {
      return function() {
        var active_editor, _ref;
        if ((_ref = _this.editor_handler) != null) {
          _ref.unsubscribe();
        }
        active_editor = atom.workspace.getActiveTextEditor();
        if (active_editor) {
          _this.editor_handler = new SublimeSelectEditorHandler(active_editor, inputCfg);
          return _this.editor_handler.subscribe();
        }
      };
    })(this)
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvdGFrYW5vcmkvLmF0b20vcGFja2FnZXMvU3VibGltZS1TdHlsZS1Db2x1bW4tU2VsZWN0aW9uL2xpYi9zdWJsaW1lLXNlbGVjdC5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsd0dBQUE7O0FBQUEsRUFBQSxXQUFBLEdBQWMsZ0NBQWQsQ0FBQTs7QUFBQSxFQUVBLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUixDQUZMLENBQUE7O0FBQUEsRUFHQSwwQkFBQSxHQUE2QixPQUFBLENBQVEseUJBQVIsQ0FIN0IsQ0FBQTs7QUFBQSxFQUtBLFVBQUE7QUFBYSxZQUFPLEVBQUUsQ0FBQyxRQUFILENBQUEsQ0FBUDtBQUFBLFdBQ04sT0FETTtlQUVUO0FBQUEsVUFBQSxTQUFBLEVBQWUsUUFBZjtBQUFBLFVBQ0EsYUFBQSxFQUFlLEtBRGY7QUFBQSxVQUVBLFFBQUEsRUFBZSxDQUZmO0FBQUEsVUFHQSxTQUFBLEVBQWUsTUFIZjtVQUZTO0FBQUEsV0FNTixRQU5NO2VBT1Q7QUFBQSxVQUFBLFNBQUEsRUFBZSxRQUFmO0FBQUEsVUFDQSxhQUFBLEVBQWUsS0FEZjtBQUFBLFVBRUEsUUFBQSxFQUFlLENBRmY7QUFBQSxVQUdBLFNBQUEsRUFBZSxNQUhmO1VBUFM7QUFBQSxXQVdOLE9BWE07ZUFZVDtBQUFBLFVBQUEsU0FBQSxFQUFlLFVBQWY7QUFBQSxVQUNBLGFBQUEsRUFBZSxPQURmO0FBQUEsVUFFQSxRQUFBLEVBQWUsQ0FGZjtBQUFBLFVBR0EsU0FBQSxFQUFlLE1BSGY7VUFaUztBQUFBO2VBaUJUO0FBQUEsVUFBQSxTQUFBLEVBQWUsVUFBZjtBQUFBLFVBQ0EsYUFBQSxFQUFlLE9BRGY7QUFBQSxVQUVBLFFBQUEsRUFBZSxDQUZmO0FBQUEsVUFHQSxTQUFBLEVBQWUsTUFIZjtVQWpCUztBQUFBO01BTGIsQ0FBQTs7QUFBQSxFQTJCQSxXQUFBLEdBQ0U7QUFBQSxJQUFBLElBQUEsRUFBUSxDQUFSO0FBQUEsSUFDQSxNQUFBLEVBQVEsQ0FEUjtBQUFBLElBRUEsS0FBQSxFQUFRLENBRlI7R0E1QkYsQ0FBQTs7QUFBQSxFQWdDQSxZQUFBLEdBQ0U7QUFBQSxJQUFBLEtBQUEsRUFBTyxVQUFQO0FBQUEsSUFDQSxHQUFBLEVBQU8sUUFEUDtBQUFBLElBRUEsSUFBQSxFQUFPLFNBRlA7R0FqQ0YsQ0FBQTs7QUFxQ0EsRUFBQSxJQUFnQyxFQUFFLENBQUMsUUFBSCxDQUFBLENBQUEsS0FBaUIsUUFBakQ7QUFBQSxJQUFBLFlBQVksQ0FBQyxHQUFiLEdBQW1CLFNBQW5CLENBQUE7R0FyQ0E7O0FBQUEsRUF1Q0EsWUFBWSxDQUFDLElBQWIsR0FBb0IsSUF2Q3BCLENBQUE7O0FBQUEsRUF5Q0EsUUFBQSxHQUFXLFVBekNYLENBQUE7O0FBQUEsRUEyQ0EsTUFBTSxDQUFDLE9BQVAsR0FFRTtBQUFBLElBQUEsTUFBQSxFQUNFO0FBQUEsTUFBQSxrQkFBQSxFQUNFO0FBQUEsUUFBQSxLQUFBLEVBQU8sY0FBUDtBQUFBLFFBQ0EsV0FBQSxFQUFjLDBGQUFBLEdBQ3lCLFVBQVUsQ0FBQyxTQURwQyxHQUM4QyxnQkFGNUQ7QUFBQSxRQUdBLElBQUEsRUFBTSxRQUhOO0FBQUEsUUFJQSxNQUFBOztBQUFPO2VBQUEsa0JBQUE7cUNBQUE7QUFBQSwwQkFBQSxJQUFBLENBQUE7QUFBQTs7WUFKUDtBQUFBLFFBS0EsU0FBQSxFQUFTLFVBQVUsQ0FBQyxTQUxwQjtPQURGO0FBQUEsTUFRQSxnQkFBQSxFQUNFO0FBQUEsUUFBQSxLQUFBLEVBQU8sWUFBUDtBQUFBLFFBQ0EsV0FBQSxFQUFjLGlGQUFBLEdBQ3lCLFVBQVUsQ0FBQyxhQURwQyxHQUNrRCxPQUZoRTtBQUFBLFFBR0EsSUFBQSxFQUFNLFFBSE47QUFBQSxRQUlBLE1BQUE7O0FBQU87ZUFBQSxtQkFBQTtzQ0FBQTtBQUFBLDBCQUFBLElBQUEsQ0FBQTtBQUFBOztZQUpQO0FBQUEsUUFLQSxTQUFBLEVBQVMsVUFBVSxDQUFDLGFBTHBCO09BVEY7S0FERjtBQUFBLElBaUJBLFFBQUEsRUFBVSxTQUFDLEtBQUQsR0FBQTtBQUNSLE1BQUEsSUFBQyxDQUFBLFNBQUQsR0FBYSxFQUFiLENBQUE7QUFBQSxNQUNBLElBQUMsQ0FBQSxjQUFELEdBQWtCLElBRGxCLENBQUE7QUFBQSxNQUdBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFnQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQVosQ0FBb0IsRUFBQSxHQUFHLFdBQUgsR0FBZSxxQkFBbkMsRUFBeUQsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsUUFBRCxHQUFBO0FBQ3ZFLFVBQUEsUUFBUSxDQUFDLFNBQVQsR0FBcUIsUUFBckIsQ0FBQTtpQkFDQSxRQUFRLENBQUMsUUFBVCxHQUFvQixXQUFZLENBQUEsUUFBQSxFQUZ1QztRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQXpELENBQWhCLENBSEEsQ0FBQTtBQUFBLE1BT0EsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBWixDQUFvQixFQUFBLEdBQUcsV0FBSCxHQUFlLG1CQUFuQyxFQUF1RCxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxRQUFELEdBQUE7QUFDckUsVUFBQSxRQUFRLENBQUMsYUFBVCxHQUF5QixRQUF6QixDQUFBO2lCQUNBLFFBQVEsQ0FBQyxTQUFULEdBQXFCLFlBQWEsQ0FBQSxRQUFBLEVBRm1DO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBdkQsQ0FBaEIsQ0FQQSxDQUFBO0FBQUEsTUFXQSxJQUFDLENBQUEsU0FBUyxDQUFDLElBQVgsQ0FBZ0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyx5QkFBZixDQUF5QyxJQUFDLENBQUEscUJBQTFDLENBQWhCLENBWEEsQ0FBQTtBQUFBLE1BWUEsSUFBQyxDQUFBLFNBQVMsQ0FBQyxJQUFYLENBQWdCLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBZixDQUF5QyxJQUFDLENBQUEscUJBQTFDLENBQWhCLENBWkEsQ0FBQTthQWFBLElBQUMsQ0FBQSxTQUFTLENBQUMsSUFBWCxDQUFnQixJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFmLENBQXlDLElBQUMsQ0FBQSxxQkFBMUMsQ0FBaEIsRUFkUTtJQUFBLENBakJWO0FBQUEsSUFpQ0EsVUFBQSxFQUFZLFNBQUEsR0FBQTtBQUNWLFVBQUEsK0JBQUE7O1lBQWUsQ0FBRSxXQUFqQixDQUFBO09BQUE7QUFDQTtBQUFBLFdBQUEsNENBQUE7NkJBQUE7QUFBQSxRQUFBLFFBQVEsQ0FBQyxPQUFULENBQUEsQ0FBQSxDQUFBO0FBQUEsT0FEQTtBQUFBLE1BRUEsSUFBQyxDQUFBLFNBQUQsR0FBYSxJQUZiLENBQUE7YUFHQSxJQUFDLENBQUEsY0FBRCxHQUFrQixLQUpSO0lBQUEsQ0FqQ1o7QUFBQSxJQXVDQSxxQkFBQSxFQUF1QixDQUFBLFNBQUEsS0FBQSxHQUFBO2FBQUEsU0FBQSxHQUFBO0FBQ3JCLFlBQUEsbUJBQUE7O2NBQWUsQ0FBRSxXQUFqQixDQUFBO1NBQUE7QUFBQSxRQUNBLGFBQUEsR0FBZ0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBZixDQUFBLENBRGhCLENBQUE7QUFFQSxRQUFBLElBQUcsYUFBSDtBQUNFLFVBQUEsS0FBQyxDQUFBLGNBQUQsR0FBc0IsSUFBQSwwQkFBQSxDQUEyQixhQUEzQixFQUEwQyxRQUExQyxDQUF0QixDQUFBO2lCQUNBLEtBQUMsQ0FBQSxjQUFjLENBQUMsU0FBaEIsQ0FBQSxFQUZGO1NBSHFCO01BQUEsRUFBQTtJQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0F2Q3ZCO0dBN0NGLENBQUE7QUFBQSIKfQ==

//# sourceURL=/home/takanori/.atom/packages/Sublime-Style-Column-Selection/lib/sublime-select.coffee
