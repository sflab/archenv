(function() {
  var helpers;

  helpers = null;

  module.exports = {
    config: {
      pep8ExecutablePath: {
        type: 'string',
        "default": 'pep8'
      },
      maxLineLength: {
        type: 'integer',
        "default": 0
      },
      ignoreErrorCodes: {
        type: 'array',
        "default": [],
        description: 'For a list of code visit http://pep8.readthedocs.org/en/latest/intro.html#error-codes'
      },
      convertAllErrorsToWarnings: {
        type: 'boolean',
        "default": true
      }
    },
    activate: function() {
      return require('atom-package-deps').install('linter-pep8');
    },
    provideLinter: function() {
      var provider;
      return provider = {
        name: 'pep8',
        grammarScopes: ['source.python', 'source.python.django'],
        scope: 'file',
        lintOnFly: true,
        lint: function(textEditor) {
          var filePath, ignoreCodes, maxLineLength, msgtype, parameters;
          if (helpers == null) {
            helpers = require('atom-linter');
          }
          filePath = textEditor.getPath();
          parameters = [];
          if (maxLineLength = atom.config.get('linter-pep8.maxLineLength')) {
            parameters.push("--max-line-length=" + maxLineLength);
          }
          if (ignoreCodes = atom.config.get('linter-pep8.ignoreErrorCodes')) {
            parameters.push("--ignore=" + (ignoreCodes.join(',')));
          }
          parameters.push('-');
          msgtype = atom.config.get('linter-pep8.convertAllErrorsToWarnings') ? 'Warning' : 'Error';
          return helpers.exec(atom.config.get('linter-pep8.pep8ExecutablePath'), parameters, {
            stdin: textEditor.getText(),
            ignoreExitCode: true
          }).then(function(result) {
            var col, line, match, regex, toReturn;
            toReturn = [];
            regex = /stdin:(\d+):(\d+):(.*)/g;
            while ((match = regex.exec(result)) !== null) {
              line = parseInt(match[1]) || 0;
              col = parseInt(match[2]) || 0;
              toReturn.push({
                type: msgtype,
                text: match[3],
                filePath: filePath,
                range: [[line - 1, col - 1], [line - 1, col]]
              });
            }
            return toReturn;
          });
        }
      };
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvdGFrYW5vcmkvLmF0b20vcGFja2FnZXMvbGludGVyLXBlcDgvbGliL21haW4uY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFBQSxNQUFBLE9BQUE7O0FBQUEsRUFBQSxPQUFBLEdBQVUsSUFBVixDQUFBOztBQUFBLEVBRUEsTUFBTSxDQUFDLE9BQVAsR0FDRTtBQUFBLElBQUEsTUFBQSxFQUNFO0FBQUEsTUFBQSxrQkFBQSxFQUNFO0FBQUEsUUFBQSxJQUFBLEVBQU0sUUFBTjtBQUFBLFFBQ0EsU0FBQSxFQUFTLE1BRFQ7T0FERjtBQUFBLE1BR0EsYUFBQSxFQUNFO0FBQUEsUUFBQSxJQUFBLEVBQU0sU0FBTjtBQUFBLFFBQ0EsU0FBQSxFQUFTLENBRFQ7T0FKRjtBQUFBLE1BTUEsZ0JBQUEsRUFDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLE9BQU47QUFBQSxRQUNBLFNBQUEsRUFBUyxFQURUO0FBQUEsUUFFQSxXQUFBLEVBQWEsdUZBRmI7T0FQRjtBQUFBLE1BVUEsMEJBQUEsRUFDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLFNBQU47QUFBQSxRQUNBLFNBQUEsRUFBUyxJQURUO09BWEY7S0FERjtBQUFBLElBZUEsUUFBQSxFQUFVLFNBQUEsR0FBQTthQUNSLE9BQUEsQ0FBUSxtQkFBUixDQUE0QixDQUFDLE9BQTdCLENBQXFDLGFBQXJDLEVBRFE7SUFBQSxDQWZWO0FBQUEsSUFrQkEsYUFBQSxFQUFlLFNBQUEsR0FBQTtBQUNiLFVBQUEsUUFBQTthQUFBLFFBQUEsR0FDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLE1BQU47QUFBQSxRQUNBLGFBQUEsRUFBZSxDQUFDLGVBQUQsRUFBa0Isc0JBQWxCLENBRGY7QUFBQSxRQUVBLEtBQUEsRUFBTyxNQUZQO0FBQUEsUUFHQSxTQUFBLEVBQVcsSUFIWDtBQUFBLFFBSUEsSUFBQSxFQUFNLFNBQUMsVUFBRCxHQUFBO0FBQ0osY0FBQSx5REFBQTs7WUFBQSxVQUFXLE9BQUEsQ0FBUSxhQUFSO1dBQVg7QUFBQSxVQUNBLFFBQUEsR0FBVyxVQUFVLENBQUMsT0FBWCxDQUFBLENBRFgsQ0FBQTtBQUFBLFVBRUEsVUFBQSxHQUFhLEVBRmIsQ0FBQTtBQUdBLFVBQUEsSUFBRyxhQUFBLEdBQWdCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwyQkFBaEIsQ0FBbkI7QUFDRSxZQUFBLFVBQVUsQ0FBQyxJQUFYLENBQWlCLG9CQUFBLEdBQW9CLGFBQXJDLENBQUEsQ0FERjtXQUhBO0FBS0EsVUFBQSxJQUFHLFdBQUEsR0FBYyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsOEJBQWhCLENBQWpCO0FBQ0UsWUFBQSxVQUFVLENBQUMsSUFBWCxDQUFpQixXQUFBLEdBQVUsQ0FBQyxXQUFXLENBQUMsSUFBWixDQUFpQixHQUFqQixDQUFELENBQTNCLENBQUEsQ0FERjtXQUxBO0FBQUEsVUFPQSxVQUFVLENBQUMsSUFBWCxDQUFnQixHQUFoQixDQVBBLENBQUE7QUFBQSxVQVFBLE9BQUEsR0FBYSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0Isd0NBQWhCLENBQUgsR0FBa0UsU0FBbEUsR0FBaUYsT0FSM0YsQ0FBQTtBQVNBLGlCQUFPLE9BQU8sQ0FBQyxJQUFSLENBQWEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLGdDQUFoQixDQUFiLEVBQWdFLFVBQWhFLEVBQTRFO0FBQUEsWUFBQyxLQUFBLEVBQU8sVUFBVSxDQUFDLE9BQVgsQ0FBQSxDQUFSO0FBQUEsWUFBOEIsY0FBQSxFQUFnQixJQUE5QztXQUE1RSxDQUFnSSxDQUFDLElBQWpJLENBQXNJLFNBQUMsTUFBRCxHQUFBO0FBQzNJLGdCQUFBLGlDQUFBO0FBQUEsWUFBQSxRQUFBLEdBQVcsRUFBWCxDQUFBO0FBQUEsWUFDQSxLQUFBLEdBQVEseUJBRFIsQ0FBQTtBQUVBLG1CQUFNLENBQUMsS0FBQSxHQUFRLEtBQUssQ0FBQyxJQUFOLENBQVcsTUFBWCxDQUFULENBQUEsS0FBa0MsSUFBeEMsR0FBQTtBQUNFLGNBQUEsSUFBQSxHQUFPLFFBQUEsQ0FBUyxLQUFNLENBQUEsQ0FBQSxDQUFmLENBQUEsSUFBc0IsQ0FBN0IsQ0FBQTtBQUFBLGNBQ0EsR0FBQSxHQUFNLFFBQUEsQ0FBUyxLQUFNLENBQUEsQ0FBQSxDQUFmLENBQUEsSUFBc0IsQ0FENUIsQ0FBQTtBQUFBLGNBRUEsUUFBUSxDQUFDLElBQVQsQ0FBYztBQUFBLGdCQUNaLElBQUEsRUFBTSxPQURNO0FBQUEsZ0JBRVosSUFBQSxFQUFNLEtBQU0sQ0FBQSxDQUFBLENBRkE7QUFBQSxnQkFHWixVQUFBLFFBSFk7QUFBQSxnQkFJWixLQUFBLEVBQU8sQ0FBQyxDQUFDLElBQUEsR0FBTyxDQUFSLEVBQVcsR0FBQSxHQUFNLENBQWpCLENBQUQsRUFBc0IsQ0FBQyxJQUFBLEdBQU8sQ0FBUixFQUFXLEdBQVgsQ0FBdEIsQ0FKSztlQUFkLENBRkEsQ0FERjtZQUFBLENBRkE7QUFXQSxtQkFBTyxRQUFQLENBWjJJO1VBQUEsQ0FBdEksQ0FBUCxDQVZJO1FBQUEsQ0FKTjtRQUZXO0lBQUEsQ0FsQmY7R0FIRixDQUFBO0FBQUEiCn0=

//# sourceURL=/home/takanori/.atom/packages/linter-pep8/lib/main.coffee
