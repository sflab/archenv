(function() {
  var CompositeDisposable;

  CompositeDisposable = require('event-kit').CompositeDisposable;

  module.exports = {
    active: false,
    isActive: function() {
      return this.active;
    },
    activate: function(state) {
      return this.subscriptions = new CompositeDisposable;
    },
    consumeMinimapServiceV1: function(minimap) {
      this.minimap = minimap;
      return this.minimap.registerPlugin('minimap-autohide', this);
    },
    deactivate: function() {
      this.minimap.unregisterPlugin('minimap-autohide');
      return this.minimap = null;
    },
    activatePlugin: function() {
      if (this.active) {
        return;
      }
      this.active = true;
      return this.minimapsSubscription = this.minimap.observeMinimaps((function(_this) {
        return function(minimap) {
          var editor, minimapElement;
          minimapElement = atom.views.getView(minimap);
          editor = minimap.getTextEditor();
          return _this.subscriptions.add(editor.onDidChangeScrollTop(function() {
            return _this.handleScroll(minimapElement);
          }));
        };
      })(this));
    },
    handleScroll: function(el) {
      el.classList.add('scrolling');
      if (el.timer) {
        clearTimeout(el.timer);
      }
      return el.timer = setTimeout((function() {
        return el.classList.remove('scrolling');
      }), 1500);
    },
    deactivatePlugin: function() {
      if (!this.active) {
        return;
      }
      this.active = false;
      this.minimapsSubscription.dispose();
      return this.subscriptions.dispose();
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiL2hvbWUvdGFrYW5vcmkvLmF0b20vcGFja2FnZXMvbWluaW1hcC1hdXRvaGlkZS9saWIvbWluaW1hcC1hdXRvaGlkZS5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLE1BQUEsbUJBQUE7O0FBQUEsRUFBQyxzQkFBdUIsT0FBQSxDQUFRLFdBQVIsRUFBdkIsbUJBQUQsQ0FBQTs7QUFBQSxFQUVBLE1BQU0sQ0FBQyxPQUFQLEdBQ0U7QUFBQSxJQUFBLE1BQUEsRUFBUSxLQUFSO0FBQUEsSUFFQSxRQUFBLEVBQVUsU0FBQSxHQUFBO2FBQUcsSUFBQyxDQUFBLE9BQUo7SUFBQSxDQUZWO0FBQUEsSUFJQSxRQUFBLEVBQVUsU0FBQyxLQUFELEdBQUE7YUFDUixJQUFDLENBQUEsYUFBRCxHQUFpQixHQUFBLENBQUEsb0JBRFQ7SUFBQSxDQUpWO0FBQUEsSUFPQSx1QkFBQSxFQUF5QixTQUFFLE9BQUYsR0FBQTtBQUN2QixNQUR3QixJQUFDLENBQUEsVUFBQSxPQUN6QixDQUFBO2FBQUEsSUFBQyxDQUFBLE9BQU8sQ0FBQyxjQUFULENBQXdCLGtCQUF4QixFQUE0QyxJQUE1QyxFQUR1QjtJQUFBLENBUHpCO0FBQUEsSUFVQSxVQUFBLEVBQVksU0FBQSxHQUFBO0FBQ1YsTUFBQSxJQUFDLENBQUEsT0FBTyxDQUFDLGdCQUFULENBQTBCLGtCQUExQixDQUFBLENBQUE7YUFDQSxJQUFDLENBQUEsT0FBRCxHQUFXLEtBRkQ7SUFBQSxDQVZaO0FBQUEsSUFjQSxjQUFBLEVBQWdCLFNBQUEsR0FBQTtBQUNkLE1BQUEsSUFBVSxJQUFDLENBQUEsTUFBWDtBQUFBLGNBQUEsQ0FBQTtPQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsTUFBRCxHQUFVLElBRlYsQ0FBQTthQUlBLElBQUMsQ0FBQSxvQkFBRCxHQUF3QixJQUFDLENBQUEsT0FBTyxDQUFDLGVBQVQsQ0FBeUIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUMsT0FBRCxHQUFBO0FBQy9DLGNBQUEsc0JBQUE7QUFBQSxVQUFBLGNBQUEsR0FBaUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFYLENBQW1CLE9BQW5CLENBQWpCLENBQUE7QUFBQSxVQUNBLE1BQUEsR0FBUSxPQUFPLENBQUMsYUFBUixDQUFBLENBRFIsQ0FBQTtpQkFFQSxLQUFDLENBQUEsYUFBYSxDQUFDLEdBQWYsQ0FBbUIsTUFBTSxDQUFDLG9CQUFQLENBQTRCLFNBQUEsR0FBQTttQkFDN0MsS0FBQyxDQUFBLFlBQUQsQ0FBYyxjQUFkLEVBRDZDO1VBQUEsQ0FBNUIsQ0FBbkIsRUFIK0M7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUF6QixFQUxWO0lBQUEsQ0FkaEI7QUFBQSxJQXlCQSxZQUFBLEVBQWMsU0FBQyxFQUFELEdBQUE7QUFDWixNQUFBLEVBQUUsQ0FBQyxTQUFTLENBQUMsR0FBYixDQUFpQixXQUFqQixDQUFBLENBQUE7QUFFQSxNQUFBLElBQUcsRUFBRSxDQUFDLEtBQU47QUFDRSxRQUFBLFlBQUEsQ0FBYSxFQUFFLENBQUMsS0FBaEIsQ0FBQSxDQURGO09BRkE7YUFLQSxFQUFFLENBQUMsS0FBSCxHQUFXLFVBQUEsQ0FBVyxDQUFFLFNBQUEsR0FBQTtlQUN0QixFQUFFLENBQUMsU0FBUyxDQUFDLE1BQWIsQ0FBb0IsV0FBcEIsRUFEc0I7TUFBQSxDQUFGLENBQVgsRUFFUixJQUZRLEVBTkM7SUFBQSxDQXpCZDtBQUFBLElBbUNBLGdCQUFBLEVBQWtCLFNBQUEsR0FBQTtBQUNoQixNQUFBLElBQUEsQ0FBQSxJQUFlLENBQUEsTUFBZjtBQUFBLGNBQUEsQ0FBQTtPQUFBO0FBQUEsTUFFQSxJQUFDLENBQUEsTUFBRCxHQUFVLEtBRlYsQ0FBQTtBQUFBLE1BR0EsSUFBQyxDQUFBLG9CQUFvQixDQUFDLE9BQXRCLENBQUEsQ0FIQSxDQUFBO2FBSUEsSUFBQyxDQUFBLGFBQWEsQ0FBQyxPQUFmLENBQUEsRUFMZ0I7SUFBQSxDQW5DbEI7R0FIRixDQUFBO0FBQUEiCn0=

//# sourceURL=/home/takanori/.atom/packages/minimap-autohide/lib/minimap-autohide.coffee
